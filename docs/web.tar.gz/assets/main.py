#!/usr/bin/env python3
"""Pickuptown Trip: a keyboard-controlled driving and resource-management game.""" 
"""# Copyright (C) 2026 Daniel Slowik
# SPDX-License-Identifier: AGPL-3.0-only
#
# This program is free software under the GNU Affero General Public License
# version 3 only. See the LICENSE file for details.
"""

import asyncio
import math
import os
import random

import pygame


pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pickuptown Trip")

FONT = pygame.font.Font(None, 25)
SMALL_FONT = pygame.font.Font(None, 20)
BIG_FONT = pygame.font.Font(None, 52)


def load_sound(filename):
    """Load an optional sound file from the folder containing this script."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)

    try:
        return pygame.mixer.Sound(path)
    except (pygame.error, FileNotFoundError):
        print(f"Sound disabled: couldn't load {filename}")
        return None


ENGINE_SOUND = load_sound("engine.ogg")
CRASH_SOUND = load_sound("crash.ogg")
ENGINE_CHANNEL = None


# Compatibility helpers for older Pygame versions.
_pygame_rect = pygame.draw.rect
_pygame_polygon = pygame.draw.polygon
_pygame_lines = pygame.draw.lines
_pygame_line = pygame.draw.line


def draw_rect(surface, color, rect, width=0):
    """Draw a rectangle after converting its coordinates to integers."""
    rect = tuple(int(round(value)) for value in rect)
    return _pygame_rect(surface, color, rect, int(width))


def draw_polygon(surface, color, points, width=0):
    """Draw a polygon after converting its points to integers."""
    points = [(int(round(x)), int(round(y))) for x, y in points]
    return _pygame_polygon(surface, color, points, int(width))


def draw_lines(surface, color, closed, points, width=1):
    """Draw connected lines after converting their points to integers."""
    points = [(int(round(x)), int(round(y))) for x, y in points]
    return _pygame_lines(surface, color, closed, points, int(width))


def draw_line(surface, color, start, end, width=1):
    """Draw a line after converting its coordinates to integers."""
    start = tuple(int(round(value)) for value in start)
    end = tuple(int(round(value)) for value in end)
    return _pygame_line(surface, color, start, end, int(width))


def draw_text(text, x, y, color=(255, 255, 255), font=FONT):
    """Draw text on the game screen."""
    surface_text = font.render(text, True, color)
    screen.blit(surface_text, (int(round(x)), int(round(y))))


ROAD_Y = 455
DESTINATION_KM = 1200.0

SERVICE_STOPS = [250.0, 520.0, 790.0, 1060.0]
EXIT_POSITIONS = [350.0, 650.0, 950.0]

SHORTCUT_DRIVE_KM = 30.0
SHORTCUT_SKIP_KM = 80.0

DIRT_TRACK_CENTER_LIMIT = 150.0
SHORTCUT_OFFROAD_PENALTY = 10.0

DIFFICULTY_DESCRIPTIONS = {
    1: "Easy — fewer obstacles",
    2: "Casual",
    3: "Normal",
    4: "Hard",
    5: "Extreme — many obstacles",
}


async def main_menu():
    """Show the starting menu; return 'play', 'instructions', or None."""
    options = ["Play", "How to Play", "Quit"]
    selected = 0

    while True:
        screen.fill((34, 55, 43))
        title = BIG_FONT.render("Pickuptown Trip", True, (255, 255, 255))
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 150)))

        for i, option in enumerate(options):
            color = (255, 230, 120) if i == selected else (220, 220, 220)
            marker = ">" if i == selected else " "
            draw_text(
                f"{marker}  {option}",
                WIDTH // 2 - 70,
                270 + i * 50,
                color,
                FONT,
            )

        draw_text(
            "Up/Down: choose   Enter: select   Esc: quit",
            WIDTH // 2 - 165,
            470,
            (205, 215, 205),
            SMALL_FONT,
        )

        draw_text(
            "Source code: https://github.com/YOUR-USERNAME/YOUR-REPOSITORY",
            WIDTH // 2 - 195 ,
            570,
            (205, 215, 205),
            SMALL_FONT,
        )

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return None
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(options)
                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(options)
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if selected == 0:
                        return "play"
                    if selected == 1:
                        return "instructions"
                    return None

        await asyncio.sleep(0)


async def show_instructions():
    """Display the objective, controls, and basic game rules."""
    lines = [
        "Goal: reach the 1,200 km destination and park your pickup.",
        "Up/Down: accelerate and brake. Left/Right: steer.",
        "E: take a shortcut when you are near an exit sign.",
        "Space: stop or park. At a service stop: 1 fuel, 2 food, 3 sleep.",
        "Fuel and food cost money. Meals are consumed every 4 in-game hours.",
        "Sleep for 8 hours to reset your awake time; 12 hours awake causes a crash.",
        "Sleeping for 8 hours costs 2 meals.",
        "Avoid traffic, rocks, and bushes; collisions cost money to repair.",
        "Shortcuts skip 80 km and save 1 hour if completed cleanly.",
        "Collisions or leaving the dirt track cancel the time bonus.",
        "Leaving the dirt track also costs 10 L of fuel.",
        "Press Enter or Esc to return to the menu.",
    ]

    while True:
        screen.fill((34, 55, 43))
        title = BIG_FONT.render("How to Play", True, (255, 255, 255))
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 105)))

        for i, line in enumerate(lines):
            draw_text(line, 55, 175 + i * 34, (235, 235, 220), SMALL_FONT)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key in (
                    pygame.K_ESCAPE,
                    pygame.K_RETURN,
                    pygame.K_KP_ENTER,
                ):
                    return True

        await asyncio.sleep(0)


async def choose_difficulty():
    """Show the difficulty screen and return the selected level, or None."""
    selected = 3

    while True:
        screen.fill((34, 55, 43))
        title = BIG_FONT.render("Pickuptown Trip", True, (255, 255, 255))
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 125)))

        draw_text(
            "Choose difficulty, then press Enter",
            WIDTH // 2 - 145,
            205,
            (235, 235, 220),
        )

        for level in range(1, 6):
            color = (255, 230, 120) if level == selected else (220, 220, 220)
            marker = ">" if level == selected else " "
            draw_text(
                f"{marker}  {level}: {DIFFICULTY_DESCRIPTIONS[level]}",
                WIDTH // 2 - 155,
                250 + (level - 1) * 38,
                color,
            )

        draw_text(
            "Arrows: choose   1-5: choose   Enter: start   Esc: back",
            WIDTH // 2 - 215,
            475,
            (205, 215, 205),
            SMALL_FONT,
        )

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return None
                if event.key in (pygame.K_LEFT, pygame.K_UP):
                    selected = max(1, selected - 1)
                elif event.key in (pygame.K_RIGHT, pygame.K_DOWN):
                    selected = min(5, selected + 1)
                elif pygame.K_1 <= event.key <= pygame.K_5:
                    selected = event.key - pygame.K_0
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    return selected

        await asyncio.sleep(0)


class PickupTrip:
    """Store trip state and handle driving, supplies, collisions, and drawing."""

    def __init__(self, difficulty=3):
        self.difficulty = difficulty
        self.reset()

    def build_obstacles(self):
        """Create randomized traffic and off-road obstacles for this trip."""
        lane_offsets = (-75, 70, 0, 85, -65, 55)
        offroad_lanes = (-80, -35, 25, 75, 0, 55, -65)

        traffic_spacing = {
            1: 5,
            2: 4,
            3: 3,
            4: 2,
            5: 1,
        }[self.difficulty]

        self.traffic = []
        km = self.rng.uniform(3.0, 7.0)

        while km < DESTINATION_KM:
            lane = self.rng.choice(lane_offsets)
            vehicle = "truck" if self.rng.random() < 0.30 else "car"
            self.traffic.append((km, lane, vehicle))
            km += self.rng.uniform(
                traffic_spacing * 0.75,
                traffic_spacing * 1.25,
            )

        self.traffic_aggression = [
            self.rng.uniform(45.0, 90.0) for _ in self.traffic
        ]
        self.traffic_lanes = [lane for _, lane, _ in self.traffic]
        self.traffic_target_lanes = [None] * len(self.traffic)

        obstacle_spacing = (5.0 - 0.75 * (self.difficulty - 1)) / 4
        self.offroad_obstacles = []

        for _ in EXIT_POSITIONS:
            obstacles = []
            obstacle_km = self.rng.uniform(1.5, 2.5)

            while obstacle_km < SHORTCUT_DRIVE_KM:
                obstacles.append(
                    (
                        obstacle_km,
                        self.rng.choice(offroad_lanes),
                        self.rng.choice(("rock", "bush")),
                    )
                )
                obstacle_km += self.rng.uniform(
                    obstacle_spacing * 0.75,
                    obstacle_spacing * 1.25,
                )

            edge_km = self.rng.uniform(2.5, 4.0)
            while edge_km < SHORTCUT_DRIVE_KM:
                for lateral in (-135, 135):
                    if self.rng.random() < 0.65:
                        obstacles.append(
                            (
                                edge_km,
                                lateral,
                                self.rng.choice(("rock", "bush")),
                            )
                        )
                edge_km += self.rng.uniform(3.0, 5.0)

            self.offroad_obstacles.append(obstacles)

    def reset(self):
        """Start a new trip with the initial supplies and vehicle state."""
        self.route_km = 0.0
        self.driven_km = 0.0
        self.speed = 0.0
        self.player_x = WIDTH / 2

        self.fuel = 30.0
        self.food = 4
        self.money = 500.0

        self.trip_minutes = 0.0
        self.awake_minutes = 0.0
        self.minutes_until_meal = 240.0

        self.parked = False
        self.offroad = False
        self.shortcut_start = None
        self.shortcut_progress = 0.0
        self.current_exit_index = None
        self.shortcut_left_track = False
        self.shortcut_clean = False

        self.used_exits = set()
        self.hit_traffic = set()
        self.hit_offroad_obstacles = set()

        self.won = False
        self.crashed = False
        self.message = "Avoid obstacles, manage supplies, and reach the destination."

        self.rng = random.Random()
        self.build_obstacles()

    def road_center(self, km):
        """Return the horizontal screen position of the road at a route distance."""
        return WIDTH / 2 + 48 * math.sin(km * 0.011) + 20 * math.sin(km * 0.031)

    def update_engine_sound(self):
        """Loop the engine sound while the truck is moving."""
        global ENGINE_CHANNEL

        if ENGINE_SOUND is None:
            return

        if self.crashed or self.won or self.parked or self.speed <= 0:
            if ENGINE_CHANNEL is not None:
                ENGINE_CHANNEL.stop()
                ENGINE_CHANNEL = None
            return

        if ENGINE_CHANNEL is None or not ENGINE_CHANNEL.get_busy():
            ENGINE_CHANNEL = ENGINE_SOUND.play(loops=-1)

        if ENGINE_CHANNEL is not None:
            volume = 0.08 + 0.45 * min(self.speed / 120.0, 1.0)
            ENGINE_CHANNEL.set_volume(volume)

    def crash(self, reason):
        """End the trip and display the reason."""
        if self.crashed:
            return

        self.crashed = True
        self.speed = 0
        self.parked = False
        self.message = reason + " Press R to start over."

        if ENGINE_CHANNEL is not None:
            ENGINE_CHANNEL.fadeout(150)

        if CRASH_SOUND is not None:
            CRASH_SOUND.play()

    def advance_time(self, minutes, sleeping=False):
        """Advance trip time and check meal and sleep requirements."""
        remaining = minutes

        while remaining > 0 and not self.crashed:
            step = min(remaining, self.minutes_until_meal)
            self.trip_minutes += step

            if not sleeping:
                self.awake_minutes += step
                if self.awake_minutes >= 12 * 60:
                    self.crash("You fell asleep at the wheel and crashed.")
                    return

            self.minutes_until_meal -= step
            remaining -= step

            if self.minutes_until_meal <= 0.001:
                if self.food > 0:
                    self.food -= 1

                    if self.food == 0:
                        self.crash("You ran out of food.")
                        return

                    self.message = "You ate a meal."
                else:
                    self.crash("You ran out of food.")
                    return

                self.minutes_until_meal = 240.0

        if sleeping and not self.crashed:
            self.awake_minutes = 0.0

    def pay(self, amount):
        """Deduct money and end the trip if the player runs out."""
        self.money -= amount

        if self.money <= 0:
            self.money = 0
            self.crash("You ran out of money.")

    def repair(self, damage):
        """Charge for collision repairs and account for repair time."""
        if self.offroad:
            self.shortcut_clean = False

        if damage == "car":
            cost, repair_minutes = 100, 45
        elif damage == "truck":
            cost, repair_minutes = 150, 60
        elif damage == "rock":
            cost, repair_minutes = 60, 30
        else:
            cost, repair_minutes = 40, 20

        self.speed = 0
        self.pay(cost)

        if not self.crashed:
            self.advance_time(repair_minutes)

            if not self.crashed:
                if CRASH_SOUND is not None:
                    CRASH_SOUND.play()

                self.message = (
                    f"Collision with a {damage}! Repairs cost ${cost} "
                    f"and took {repair_minutes} minutes."
                )

    def service_index(self):
        """Return the service-stop index if the truck is parked beside one."""
        if self.offroad:
            return None

        for i, stop in enumerate(SERVICE_STOPS):
            pad_x = self.road_center(stop) + 210
            if (
                abs(self.route_km - stop) < 0.6
                and abs(self.player_x - pad_x) < 75
            ):
                return i

        return None

    def take_shortcut(self):
        """Enter an unused shortcut if the truck is near an exit."""
        if self.offroad or self.parked or self.crashed or self.won:
            return

        for i, exit_km in enumerate(EXIT_POSITIONS):
            if i in self.used_exits:
                continue

            if -3.5 <= self.route_km - exit_km <= 0.5:
                self.used_exits.add(i)
                self.offroad = True
                self.shortcut_start = self.route_km
                self.shortcut_progress = 0.0
                self.current_exit_index = i
                self.shortcut_left_track = False
                self.shortcut_clean = True
                self.message = "Off-road shortcut! Dodge rocks and bushes."
                return

        self.message = "No exit nearby. Press E as you approach an exit sign."

    def buy_fuel(self):
        """Buy up to 25 L of fuel for $75."""
        price = 75

        if self.fuel >= 55:
            self.message = "Tank is already nearly full."
        elif self.money < price:
            self.message = "Not enough money for fuel."
        else:
            self.fuel = min(55.0, self.fuel + 25.0)
            self.pay(price)

            if not self.crashed:
                self.advance_time(10)
                if not self.crashed:
                    self.message = "Added up to 25 L of fuel: $75 and 10 minutes."

    def buy_food(self):
        """Buy four meals for $25."""
        price = 25

        if self.money < price:
            self.message = "Not enough money for food."
        else:
            self.food += 4
            self.pay(price)

            if not self.crashed:
                self.advance_time(10)
                if not self.crashed:
                    self.message = "Bought 4 meals: $25 and 10 minutes."

    def sleep(self):
        """Sleep for eight hours and reset the awake-time counter."""
        self.message = "Sleeping for 8 hours..."
        self.advance_time(8 * 60, sleeping=True)

        if not self.crashed:
            self.message = "You slept for 8 hours and are rested."

    def update(self, dt, keys):
        """Update driving, resource use, time, and collision checks."""
        if self.won or self.crashed:
            return

        # One real second represents one in-game minute.
        self.advance_time(dt)
        if self.crashed:
            return

        if self.parked:
            return

        if keys[pygame.K_UP]:
            self.speed = min(120.0, self.speed + 45.0 * dt)
        if keys[pygame.K_DOWN]:
            self.speed = max(0.0, self.speed - 75.0 * dt)

        if keys[pygame.K_LEFT]:
            self.player_x -= 250 * dt
        if keys[pygame.K_RIGHT]:
            self.player_x += 250 * dt

        self.player_x = max(35, min(WIDTH - 35, self.player_x))

        if self.route_km >= DESTINATION_KM:
            self.route_km = DESTINATION_KM
            self.speed = 0
            return

        old_route = self.route_km
        old_shortcut_progress = self.shortcut_progress

        simulated_seconds = dt * 60.0
        distance_step = self.speed * simulated_seconds / 3600.0

        if self.offroad:
            self.speed = min(self.speed, 65.0)
            self.shortcut_progress += distance_step

        self.route_km += distance_step
        self.driven_km += distance_step
        self.route_km = min(self.route_km, DESTINATION_KM)

        road_offset = abs(self.player_x - self.road_center(self.route_km))

        if self.offroad:
            track_center = self.road_center(self.route_km)
            road_offset = abs(self.player_x - track_center)

            if road_offset > DIRT_TRACK_CENTER_LIMIT:
                self.shortcut_clean = False

                self.player_x = track_center + (
                    DIRT_TRACK_CENTER_LIMIT
                    if self.player_x > track_center
                    else -DIRT_TRACK_CENTER_LIMIT
                )

                if not self.shortcut_left_track:
                    self.shortcut_left_track = True
                    self.fuel -= SHORTCUT_OFFROAD_PENALTY
                    self.message = "Left the dirt track! Lost 10 L of fuel."

                    if self.fuel <= 0:
                        self.fuel = 0
                        self.crash("You ran out of fuel.")
                        return

            fuel_rate = 0.16
        else:
            fuel_rate = 0.095
            if road_offset > 175:
                self.speed = min(self.speed, 35.0)
                self.message = (
                    "You're off the paved shoulder—steer back onto the road."
                )

        self.fuel -= distance_step * fuel_rate
        if self.fuel <= 0:
            self.fuel = 0
            self.crash("You ran out of fuel.")
            return

        # Check rocks and bushes on the active shortcut.
        if self.offroad and self.current_exit_index is not None:
            obstacles = self.offroad_obstacles[self.current_exit_index]

            for i, (obstacle_km, lateral, kind) in enumerate(obstacles):
                key = (self.current_exit_index, i)

                if key in self.hit_offroad_obstacles:
                    continue

                if (
                    old_shortcut_progress - 0.15
                    <= obstacle_km
                    <= self.shortcut_progress + 0.15
                ):
                    obstacle_x = self.road_center(self.route_km) + lateral

                    if abs(self.player_x - obstacle_x) < 45:
                        self.hit_offroad_obstacles.add(key)
                        self.repair(kind)
                        break

        if self.crashed:
            return

        # Each vehicle locks onto the player's position only once.
        if not self.offroad:
            for i, (traffic_km, _, _) in enumerate(self.traffic):
                if i in self.hit_traffic:
                    continue

                ahead = traffic_km - self.route_km
                if -0.15 <= ahead <= 3.5:
                    if self.traffic_target_lanes[i] is None:
                        road_center = self.road_center(traffic_km)
                        self.traffic_target_lanes[i] = max(
                            -125.0,
                            min(125.0, self.player_x - road_center),
                        )

                    target_lane = self.traffic_target_lanes[i]
                    current_lane = self.traffic_lanes[i]
                    difference = target_lane - current_lane
                    max_shift = self.traffic_aggression[i] * dt

                    if difference > 0:
                        self.traffic_lanes[i] += min(difference, max_shift)
                    elif difference < 0:
                        self.traffic_lanes[i] += max(difference, -max_shift)

        # Check cars and trucks on the paved road.
        if not self.offroad:
            for i, (traffic_km, _, vehicle) in enumerate(self.traffic):
                if i in self.hit_traffic:
                    continue

                if old_route - 0.15 <= traffic_km <= self.route_km + 0.15:
                    traffic_x = (
                        self.road_center(traffic_km) + self.traffic_lanes[i]
                    )

                    if abs(self.player_x - traffic_x) < 48:
                        self.hit_traffic.add(i)
                        self.repair(vehicle)
                        break

        if self.crashed:
            return

        # Rejoin the highway after completing a shortcut.
        if self.offroad and self.shortcut_progress >= SHORTCUT_DRIVE_KM:
            completed_cleanly = self.shortcut_clean

            self.route_km = min(
                self.shortcut_start + SHORTCUT_SKIP_KM,
                DESTINATION_KM,
            )
            self.offroad = False
            self.shortcut_start = None
            self.shortcut_progress = 0.0
            self.current_exit_index = None

            if completed_cleanly:
                self.trip_minutes = max(0.0, self.trip_minutes - 60.0)
                self.message = (
                    "Clean shortcut! Saved 1 hour. Back on the paved road."
                )
            else:
                self.message = (
                    "Back on the paved road. No time bonus for this shortcut."
                )

        if self.route_km >= DESTINATION_KM:
            self.route_km = DESTINATION_KM
            self.speed = 0

    def handle_space(self):
        """Stop, resume, or park at the destination."""
        if self.won or self.crashed:
            return

        if self.parked:
            self.parked = False
            self.message = "Back on the road."
            return

        self.speed = 0

        if self.route_km >= DESTINATION_KM - 0.1:
            if abs(self.player_x - self.road_center(DESTINATION_KM)) < 100:
                self.parked = True
                self.won = True
                self.message = "Trip complete!"
            else:
                self.message = (
                    "Steer into the destination parking area, then press Space."
                )
        else:
            self.parked = True
            self.message = "Stopped. Use 1, 2, or 3 at a roadside service stop."

    def draw(self):
        """Draw the road, vehicles, dashboard, and game-status overlays."""
        screen.fill((92, 145, 76))

        # Draw the road or dirt track.
        left, right = [], []

        for ahead in range(36, -1, -1):
            km = self.route_km + ahead * 0.1
            y = ROAD_Y - ahead * 12
            width = 175 - ahead * 1.25
            center = self.road_center(km)
            left.append((center - width, y))
            right.append((center + width, y))

        road_color = (128, 102, 68) if self.offroad else (72, 72, 70)
        draw_polygon(screen, road_color, left + right[::-1])

        if not self.offroad:
            for side in (-1, 1):
                edge = [
                    (
                        self.road_center(self.route_km + ahead * 0.1)
                        + side * (175 - ahead * 1.25),
                        ROAD_Y - ahead * 12,
                    )
                    for ahead in range(36, -1, -1)
                ]
                draw_lines(screen, (235, 230, 190), False, edge, 3)

            for ahead in range(0, 36, 4):
                km = self.route_km + ahead * 0.1
                y = ROAD_Y - ahead * 12
                center = self.road_center(km)
                draw_line(
                    screen,
                    (220, 205, 130),
                    (center, y),
                    (center, y - 20),
                    3,
                )

            # Rest-stop parking pads.
            for stop in SERVICE_STOPS:
                ahead = stop - self.route_km
                if 0 <= ahead <= 3.5:
                    y = ROAD_Y - ahead * 120
                    x = self.road_center(stop) + 210
                    draw_rect(
                        screen, (155, 155, 145), (x - 35, y - 14, 70, 28)
                    )
                    draw_text("P", x - 6, y - 11, (20, 20, 20), SMALL_FONT)
                    draw_text(
                        "GAS / FOOD",
                        x - 45,
                        y - 37,
                        (255, 245, 170),
                        SMALL_FONT,
                    )

            # Shortcut exit signs.
            for i, exit_km in enumerate(EXIT_POSITIONS):
                ahead = exit_km - self.route_km
                if i not in self.used_exits and 0 <= ahead <= 4.0:
                    y = ROAD_Y - ahead * 120
                    x = self.road_center(exit_km) + 155
                    draw_rect(
                        screen, (30, 100, 48), (x - 52, y - 21, 105, 31)
                    )
                    draw_text(
                        "EXIT - E",
                        x - 38,
                        y - 15,
                        (255, 255, 255),
                        SMALL_FONT,
                    )

            # Destination parking marker.
            ahead = DESTINATION_KM - self.route_km
            if 0 <= ahead <= 3.5:
                y = ROAD_Y - ahead * 120
                x = self.road_center(DESTINATION_KM)
                draw_rect(
                    screen, (190, 190, 180), (x - 62, y - 15, 124, 30)
                )
                draw_text(
                    "DESTINATION",
                    x - 52,
                    y - 11,
                    (20, 20, 20),
                    SMALL_FONT,
                )

        # Draw rocks and bushes on the active shortcut.
        if self.offroad and self.current_exit_index is not None:
            obstacles = self.offroad_obstacles[self.current_exit_index]

            for i, (obstacle_km, lateral, kind) in enumerate(obstacles):
                key = (self.current_exit_index, i)
                ahead = obstacle_km - self.shortcut_progress

                if key in self.hit_offroad_obstacles or not 0 <= ahead <= 3.5:
                    continue

                y = ROAD_Y - ahead * 120
                x = self.road_center(self.route_km) + lateral

                if kind == "rock":
                    draw_polygon(
                        screen,
                        (100, 65, 45),
                        [(x, y - 17), (x - 17, y + 13), (x + 17, y + 13)],
                    )
                else:
                    pygame.draw.circle(
                        screen, (35, 95, 40), (int(x), int(y)), 15
                    )
                    pygame.draw.circle(
                        screen, (45, 115, 48), (int(x - 9), int(y + 5)), 10
                    )
                    pygame.draw.circle(
                        screen, (30, 80, 35), (int(x + 9), int(y + 5)), 10
                    )

        # Draw cars and trucks on the highway.
        if not self.offroad:
            for i, (traffic_km, _, vehicle) in enumerate(self.traffic):
                if i in self.hit_traffic:
                    continue

                ahead = traffic_km - self.route_km
                if 0 <= ahead <= 3.5:
                    y = ROAD_Y - ahead * 120
                    x = self.road_center(traffic_km) + self.traffic_lanes[i]

                    if vehicle == "truck":
                        draw_rect(
                            screen, (45, 95, 160), (x - 24, y - 29, 48, 58)
                        )
                        draw_rect(
                            screen, (145, 190, 205), (x - 17, y - 23, 34, 14)
                        )
                    else:
                        draw_rect(
                            screen, (175, 60, 45), (x - 18, y - 23, 36, 46)
                        )
                        draw_rect(
                            screen, (180, 215, 220), (x - 12, y - 16, 24, 12)
                        )

        # Draw the player's pickup truck.
        truck_y = ROAD_Y
        draw_rect(
            screen, (12, 12, 15), (self.player_x - 23, truck_y - 34, 46, 68)
        )
        draw_rect(
            screen, (60, 65, 68), (self.player_x - 16, truck_y - 25, 32, 20)
        )
        draw_rect(
            screen, (20, 20, 22), (self.player_x - 18, truck_y + 4, 36, 17)
        )
        draw_rect(
            screen,
            (230, 220, 150),
            (self.player_x - 18, truck_y - 33, 10, 5),
        )
        draw_rect(
            screen,
            (230, 220, 150),
            (self.player_x + 8, truck_y - 33, 10, 5),
        )

        # Draw the dashboard.
        draw_rect(screen, (20, 24, 27), (0, 0, WIDTH, 85))
        draw_text(f"Route: {self.route_km:5.0f} / {DESTINATION_KM:.0f} km", 14, 10)
        draw_text(f"Speed: {self.speed:3.0f} km/h", 250, 10)
        draw_text(f"Fuel: {self.fuel:4.1f} L", 420, 10)
        draw_text(f"Food: {self.food}", 550, 10)
        draw_text(f"Money: ${self.money:.0f}", 650, 10)
        draw_text(
            f"Level: {self.difficulty}/5",
            785,
            10,
            (255, 230, 120),
            SMALL_FONT,
        )

        draw_text(
            f"Trip time: {int(self.trip_minutes // 60)}h "
            f"{int(self.trip_minutes % 60)}m",
            14,
            48,
        )
        draw_text(
            f"Awake: {int(self.awake_minutes // 60)}h "
            f"{int(self.awake_minutes % 60)}m / 12h",
            250,
            48,
            (255, 220, 120)
            if self.awake_minutes > 8 * 60
            else (220, 220, 220),
        )
        draw_text(
            "Arrows: drive/steer   E: exit   Space: stop/park",
            570,
            48,
            (220, 220, 220),
            SMALL_FONT,
        )

        # Draw the status-message bar.
        draw_rect(screen, (20, 24, 27), (0, HEIGHT - 38, WIDTH, 38))
        draw_text(
            self.message,
            14,
            HEIGHT - 31,
            (245, 245, 220),
            SMALL_FONT,
        )

        if self.offroad:
            draw_text(
                "OFF-ROAD: dodge rocks and bushes; no gas or food stops until you rejoin",
                90,
                100,
                (255, 235, 150),
                SMALL_FONT,
            )

        if self.parked and self.service_index() is not None:
            draw_text(
                "Rest stop: 1 Fuel ($75, +25 L)   2 Food ($25, +4 meals)   3 Sleep (8 hours)",
                130,
                110,
                (255, 245, 160),
                SMALL_FONT,
            )

        if self.won:
            self.show_overlay(
                [
                    "Trip complete!",
                    f"Time: {int(self.trip_minutes // 60)}h "
                    f"{int(self.trip_minutes % 60)}m",
                    f"Money left: ${self.money:.0f}   "
                    f"Distance driven: {self.driven_km:.0f} km",
                    "Press Esc to return to menu",
                ]
            )
        elif self.crashed:
            self.show_overlay(
                [
                    "Trip over!",
                    self.message,
                    "Press R to start over",
                ]
            )

    def show_overlay(self, lines):
        """Draw a translucent message overlay over the game."""
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 175))
        screen.blit(overlay, (0, 0))

        y = HEIGHT // 2 - len(lines) * 25
        for i, line in enumerate(lines):
            font = BIG_FONT if i == 0 else FONT
            text = font.render(line, True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=(WIDTH // 2, y)))
            y += 48

async def main():
    """Run the menu, difficulty selection, and game sessions."""
    loop = asyncio.get_running_loop()
    running = True

    while running:
        choice = await main_menu()

        if choice is None:
            break

        if choice == "instructions":
            running = await show_instructions()
            continue

        difficulty = await choose_difficulty()
        if difficulty is None:
            continue

        game = PickupTrip(difficulty)
        game_running = True
        last_frame = loop.time()

        while running and game_running:
            now = loop.time()
            dt = min(now - last_frame, 0.05)
            last_frame = now
            keys = pygame.key.get_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    game_running = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        game_running = False
                    elif event.key == pygame.K_r and game.crashed:
                        game.reset()
                    elif event.key == pygame.K_e:
                        game.take_shortcut()
                    elif event.key == pygame.K_SPACE:
                        game.handle_space()
                    elif game.parked and game.service_index() is not None:
                        if event.key == pygame.K_1:
                            game.buy_fuel()
                        elif event.key == pygame.K_2:
                            game.buy_food()
                        elif event.key == pygame.K_3:
                            game.sleep()

            if not running or not game_running:
                break

            game.update(dt, keys)
            game.update_engine_sound()
            game.draw()
            pygame.display.flip()
            await asyncio.sleep(0)


asyncio.run(main())

